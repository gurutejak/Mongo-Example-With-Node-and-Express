var http = require('http');
var url = require('url');
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var UserModel = require('./../../models/model.js');

//Mongo
console.log("inside 1");
// mongoose.Promise = global.Promise;
// mongoose.connect('mongodb://localhost/product');

// var userSchema = new mongoose.Schema({
//     name: String,
//     email: String,
//     password: String
// })

// var User = mongoose.model('User', userSchema)

router.use(function (req, res, next) {
    console.log("In Middleware");
    next();
});

router.get('/', function (req, res, next) {
    res.render('../views/User/register.html');
    console.log("In Register");
});

router.post('/saveUser', function (req, res) {
    console.log(req.body.username);
    res.send('Registerd User: ' + req.body.username);
    var newMember = UserModel({
        name: req.body.username,
        email: req.body.email,
        password: req.body.password
    })

    newMember.save(function (err) {
        if (err) throw err;
        console.log('User created!');
    });
});

router.get('/getUsers', function (req, res){
    console.log("inside getuser ");
    UserModel.find({}, function(err, users) {
        if (err) throw err;
      
        // object of all the users
        console.log(users);
        res.send(users);
      });
})

module.exports = router;