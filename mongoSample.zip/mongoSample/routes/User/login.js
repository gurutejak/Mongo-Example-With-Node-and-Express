var LocalStrategy = require('passport-local').Strategy;
var passport = require('passport');
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var UserModel = require('./../../models/model.js');


//Mongo
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/product');

router.use(function (req, res, next) {
    console.log("Login Middleware");
    next();
});

router.get('/',
    function (req, res) {
        console.log("Im here")
        res.render('../views/User/login.html');
    });

passport.use(new LocalStrategy(
    function (username, password, callback) {
        var userEmail = username;
        var userPassword = password;
        console.log("passport-local");
        
        UserModel.find({ email: userEmail }, function (err, user) {
            if (err) throw err;
            var jsonString = JSON.stringify(user[0]);
            var obj = JSON.parse(jsonString);
            if (obj.email == userEmail && obj.password == userPassword) {
                console.log("1");
                return callback(null, username);
            }
            else {
                console.log("2");
                console.log(email + " - " + userEmail)
                return callback(err);
                // res.send("login failed")
            }
	    });
    }));

router.post('/authenticate', passport.authenticate('local', { failureRedirect: '/login' }),
    function (req, res) {
        console.log(req.user);
        showUsers();
        res.cookie('username', req.user, { maxAge: 30000 }).send("Welcome " + req.user)
    });

function getUserWithEmail(email, password) {
    console.log("User Email enterd is " + email);
    UserModel.find({ email: email }, function (err, user) {
        if (err) throw err;
        console.log('login success 1');
    });
}

function showUsers()
{
    console.log("inside getuser ");
    UserModel.find({}, function (err, users) {
        if (err) throw err;
        console.log(users);
        res.send(users);
    });
}

router.get('/getUsers', function (req, res) {
    console.log("inside getuser ");
    UserModel.find({}, function (err, users) {
        if (err) throw err;
        console.log(users);
        res.send(users);
    });
})
passport.serializeUser(function (user, callback) {
    callback(null, user);
});

passport.deserializeUser(function (id, callback) {
    callback(null, id);
});


module.exports = router;