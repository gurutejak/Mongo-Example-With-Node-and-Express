var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/product');

var userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String
})

var User = mongoose.model('User', userSchema)
module.exports = User;